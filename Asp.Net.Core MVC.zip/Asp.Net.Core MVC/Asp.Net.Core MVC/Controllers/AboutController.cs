﻿using Microsoft.AspNetCore.Mvc;

namespace Asp.Net.Core_MVC.Controllers
{
    public class AboutController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Detail(int id)
        {
            ViewBag.Id = id;
            return View();
        }
    }
}
