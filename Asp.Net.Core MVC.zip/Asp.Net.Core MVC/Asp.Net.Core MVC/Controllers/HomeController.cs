﻿using Microsoft.AspNetCore.Mvc;

namespace Asp.Net.Core_MVC.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Detail()
        {
            return View();
        }
    }
}
